const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");

const app = express();
app.use(bodyParser.json());

// MongoDB Connection
mongoose.connect("mongodb://[Log in to view URL]:27017/studentDB")
.then(() => console.log("MongoDB Connected"))
.catch(err => console.log(err));

// Student Schema
const studentSchema = new mongoose.Schema({
    name: String,
    rollNo: String,
    course: String,
    marks: Number
});

// Student Model
const Student = mongoose.model("Student", studentSchema);

// Add Student
app.post("/students", async (req, res) => {
    try {
        const student = new Student(req.body);
        await student.save();
        res.json({ message: "Student Added Successfully" });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get All Students
app.get("/students", async (req, res) => {
    try {
        const students = await Student.find();
        res.json(students);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get Student by ID
app.get("/students/:id", async (req, res) => {
    try {
        const student = await Student.findById(req.params.id);
        res.json(student);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Update Student
app.put("/students/:id", async (req, res) => {
    try {
        await Student.findByIdAndUpdate(req.params.id, req.body